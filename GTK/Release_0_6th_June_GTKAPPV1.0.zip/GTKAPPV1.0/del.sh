
#mkdir $1
rm -rf $1
