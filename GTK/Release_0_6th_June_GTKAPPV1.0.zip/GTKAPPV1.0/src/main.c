#include"include/main.h"

extern int StartGtk(void);
extern void GoToMainScreen(void);

int MainWindowEn,SetWindowEn,ConfWindowEn,ConfDeleteWindowEn,ConfAddWindowEn;
GtkBuilder *ConfBuilder,*ConfAddBuilder,*ConfDeleteBuilder, *SetBuilder, *PopBuilder,*BpBuilder,*DelPopBuilder,*AddDetailBuilder;
GtkWidget *MainWindow,*Bliwindow,*ConfWindow,*ConfAddWindow,*ConfDeleteWindow,*SettingWindow,*PopWindow,*DelPopWindow,*AddDetailWindow;

void destroy (GtkWidget *widget, gpointer data)
{
	gtk_main_quit ();
}

int main (int argc, char *argv[])
{
	int ret = 0;
	#ifdef ENABLE_NLS
		bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
		bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
		textdomain (GETTEXT_PACKAGE);
	#endif	
	
	gtk_init (&argc, &argv);	
	ret = StartGtk();
	return ret;
}







