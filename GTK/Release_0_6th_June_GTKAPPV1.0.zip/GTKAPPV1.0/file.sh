#cd $1
touch $1
