README.txt
==========

Compile the driver char_driver_async.c using the normal compile 
procedures. Insert it into the kernel blob using insmod.

There are two programs in this directory
reader.c, writer.c

compile each program and have different executables.

Run reader in one console
Run writer in another console

and in that order. 

Notice the program output and arrive at the conclusions.
