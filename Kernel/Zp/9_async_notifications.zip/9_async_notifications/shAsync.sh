clear 
echo
echo "Asynch Char Driver";
echo
make clean
make
rm -rf reader
rm -rf writer
gcc reader.c -o reader
gcc writer.c -o writer

echo "Press y to run the make or n to come out"
read Var0
if [ "$Var0" == "y" ] || [ "$Var0" == "Y" ]; then 
	echo 
	echo "Press y to removing the node in Driver "
	read Var1
	if [ "$Var0" == "y" ] || [ "$Var0" == "Y" ]; then 
		su -c "rmmod chr_drv_async.ko"
	fi
	echo "Press y to inserting the node in Driver "
	read Var2
	if [ "$Var0" == "y" ] || [ "$Var0" == "Y" ]; then 
		su -c "insmod chr_drv_async.ko"
	fi
	echo "User is running app"
	su -c "./reader"
fi

echo "Byeeeeeeee"
echo
