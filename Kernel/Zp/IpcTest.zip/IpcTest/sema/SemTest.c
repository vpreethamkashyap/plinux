# include <stdio.h>

	
void IPC_Semaphore_Test(void)
{
	Printf("Hi Usr You are going to Test IPC PIPE as Server\n");
}
