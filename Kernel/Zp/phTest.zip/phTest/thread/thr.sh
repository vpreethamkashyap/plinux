clear
gcc -pthread thread.c -o oth
./oth
