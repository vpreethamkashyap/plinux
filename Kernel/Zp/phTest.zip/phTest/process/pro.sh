#!/bin/bash
# My First Script
clear
path=$(pwd)
cd $path/
echo $path 

gcc process.c -o pes


while :
do	
		echo
		echo "press any key to start the process"
		read proc
		clear
		echo
		./pes 		
done

