// typedef in structure//

#include<stdio.h>
main()
{

 struct book
 {
  float price;
  int pages;
};
//typedef//
typedef struct book book;
book b1,b2;
printf("Enter prices and no. of pages\n");
scanf("%f%d",&b1.price,&b1.pages);
scanf("%f%d",&b2.price,&b2.pages);
printf("the entered data\n");
scanf("%f%d",b1.price,b1.pages);
scanf("%f%d",b2.price,b2.pages);
}

