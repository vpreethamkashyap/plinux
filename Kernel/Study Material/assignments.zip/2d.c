//2d array initialization//

#include<stdio.h>
main()
{
  int stud[4][2];
  int i,j;

//initializing array//
  for(i=0;i<4;i++)
   {
     for(j=0;j<2;j++)
      {
        printf("Enter roll no and marks:");
        scanf("%d",&stud[i][j]);
      }
   }
   

   for(i=0;i<4;i++)
   {
     for(j=0;j<2;j++)
      {
        printf("a[%d][%d]=%d\n",i,j,stud[i][j]);
        
      }
   }
}
