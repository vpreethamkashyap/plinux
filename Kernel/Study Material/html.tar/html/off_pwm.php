<!DOCTYPE html>
<html>
<body text="white" bgcolor="black">
<basefont size="7">
<button style="position: absolute; right: 0; font-size : 40px; height:100px;width:100px"; onclick="window.location.href='start.html'">Back</button><br><br>


<?php 
shell_exec("echo 0 >  /sys/class/pwm/pwmchip0/pwm0/enable");
?>
<br>
<h1>PWM channel 0 de-activated - BBB"</h1>.
</body>
</html> 
