echo "GPIO is high"
echo 1 > /sys/class/gpio/gpio60/value 
