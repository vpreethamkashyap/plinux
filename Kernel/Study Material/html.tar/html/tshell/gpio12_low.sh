echo "GPIO is low " 
echo 0 > /sys/class/gpio/gpio60/value


