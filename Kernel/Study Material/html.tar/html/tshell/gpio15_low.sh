echo "GPIO is low"
echo 0 > /sys/class/gpio/gpio48/value

