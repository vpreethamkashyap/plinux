<html>
<head>
<title>Test</title>
</head>
<body>
<?php 
print "PHP is working on the BeagleBone!"; 
?>
</body>
</html>
