<?php
$myfile = fopen("gpio.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("gpio.txt"));
fclose($myfile);
?>
