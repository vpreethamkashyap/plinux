<!DOCTYPE html>
<html>
<body>

<?php
print "Hello world!";
?>

</body>
</html>
