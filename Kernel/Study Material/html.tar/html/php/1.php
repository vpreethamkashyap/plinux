
<?php 
print "PHP is working on the BeagleBone!"; 
?>


