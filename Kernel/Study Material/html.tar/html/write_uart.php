<!DOCTYPE html>
<html>
<body text="white" bgcolor="black">
<basefont size="7">
<button style="position: absolute; right: 0; font-size : 40px; height:100px;width:100px"; onclick="window.location.href='start.html'">Back</button><br><br>

<br>
<br>
<h1>UART-4 receving data - BBB"</h1>.
</body>
</html>

<?php
$UART_TX =  $_GET["utx"];
$urx = shell_exec("python /var/www/html/tshell/uart_send.py $UART_TX ");
?>



<form id="frm1" action=""  
<h1>.</h1> <input style="font-size : 40px; height:100px;width:400px";type="text" name="urx" value= '<?php echo "$urx";?>'<br><br>

</form>
 
