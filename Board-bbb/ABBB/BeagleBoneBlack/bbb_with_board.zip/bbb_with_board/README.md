beaglebone-getting-started
==========================

BeagleBone Getting Started Guide

Please open START.htm in your web browser to view the guide.

Please submit any improvements to https://github.com/jadonk/beaglebone-getting-started.

For bone101, see https://github.com/jadonk/bone101.
